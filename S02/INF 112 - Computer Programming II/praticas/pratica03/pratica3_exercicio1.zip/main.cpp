#include <iostream>
#include "listavetorinteiros.h"

int main(){
    ListaVetorInteiros obj;
    int resp;

    std::cout<<"Digite os numeros para completar a lista, quando desejar finaliza digite 0: ";

    while(true){
        std::cin>>resp;
        if(resp==0){
            break;
        }
        obj.inserir_elemento(resp);
    }
    obj.imprimir();
    obj.inverter();
    obj.imprimir();
    obj.remover_primeiro();
    obj.imprimir();
    obj.remover_ultimo();
    obj.imprimir();

    return 0;
}