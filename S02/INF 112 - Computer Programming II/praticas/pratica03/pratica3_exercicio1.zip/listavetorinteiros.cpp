#include <iostream>
#include "listavetorinteiros.h"

ListaVetorInteiros::ListaVetorInteiros() {
    _elementos = new int[TAMANHO_INICIAL]();
    _num_elementos_inseridos = 0;
    _capacidade = TAMANHO_INICIAL;
}

void ListaVetorInteiros::inserir_elemento(int elemento){
    if (_num_elementos_inseridos == _capacidade){
        int *new_data = new int[_capacidade * 2];
        for (int i = 0; i < _num_elementos_inseridos; i++)
            new_data[i] = _elementos[i];
        delete[] _elementos;
        _elementos = new_data;
        _capacidade = _capacidade * 2;
    }
    _elementos[_num_elementos_inseridos] = elemento;
    _num_elementos_inseridos++;
    std::cout << "Elemento inserido...\n";
}

ListaVetorInteiros::~ListaVetorInteiros() {
    delete[] _elementos;
}

void ListaVetorInteiros::imprimir() {
    std::cout<<"Imprimindo..."<<std::endl;
    for (int i = 0; i < _num_elementos_inseridos; i++)
        std::cout << _elementos[i] << " ";
    std::cout << std::endl;
}



void ListaVetorInteiros::remover_primeiro(){
    std::cout<<"Removendo primeiro elemento..."<<std::endl;
    int *new_data = new int[_capacidade];
    _num_elementos_inseridos--;
    for(int i=0;i<_num_elementos_inseridos;i++){
        new_data[i] = _elementos[i+1];
    }
    delete[] _elementos;
    _elementos = new_data;
}

void ListaVetorInteiros::remover_ultimo(){
    std::cout<<"Removendo ultimo elemento..."<<std::endl;
    int *new_data = new int[_capacidade];
    _num_elementos_inseridos--;
    for(int i=0;i<_num_elementos_inseridos;i++){
        new_data[i] = _elementos[i];
    }
    delete[] _elementos;
    _elementos = new_data;
}

void ListaVetorInteiros::inverter(){
    std::cout<<"Invertendo..."<<std::endl;
    int *new_data = new int[_num_elementos_inseridos];
    for(int i=0;i<_num_elementos_inseridos;i++){
        new_data[i] = _elementos[_num_elementos_inseridos-1-i];
    }
    delete[] _elementos;
    _elementos = new_data;
} 