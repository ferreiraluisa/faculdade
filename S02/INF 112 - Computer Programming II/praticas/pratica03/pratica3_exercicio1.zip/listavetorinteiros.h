#define TAMANHO_INICIAL 100

struct ListaVetorInteiros {
// Dados
int *_elementos;
int _num_elementos_inseridos;
int _capacidade;

// Construtor
ListaVetorInteiros();
// Destrutor
~ListaVetorInteiros();
// Insere um inteiro na lista
void inserir_elemento(int elemento);
// Imprime a lista
void imprimir();
//Reverter veter
void inverter();
//Excluir primeiro elemento
void remover_primeiro();
//Excluir ultimo elemento
void remover_ultimo();
};