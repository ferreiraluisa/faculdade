#include <iostream>
#include "data.h"

Data::Data(int dia, int mes, int ano){
    _dia = dia;
    _mes = mes;
    _ano = ano;
}

Data::~Data(){}

void Data::Barra(){
    if(_dia<10){
        std::cout<<"0"<<_dia<<"/";
    }
    else{
        std::cout<<_dia<<"/";
    }
    if(_mes<10){
        std::cout<<"0"<<_mes<<"/";
    }
    else{
        std::cout<<_mes<<"/";
    }
    std::cout<<_ano<<std::endl;
}

void Data::Extenso(){
    std::cout<<_dia<<" de ";
    if(_mes==1){
        std::cout<<" Janeiro de ";
    }
    if(_mes==2){
        std::cout<<" Fevereiro de ";
    }
    if(_mes==3){
        std::cout<<" Marco de ";
    }
    if(_mes==4){
        std::cout<<" Abril de ";
    }
    if(_mes==5){
        std::cout<<" Maio de ";
    }
    if(_mes==6){
        std::cout<<" Junho de ";
    }
    if(_mes==7){
        std::cout<<" Julho de ";
    }
    if(_mes==8){
        std::cout<<" Agosto de ";
    }
    if(_mes==9){
        std::cout<<" Setembro de ";
    }
    if(_mes==10){
        std::cout<<" Outubro de ";
    }
    if(_mes==11){
        std::cout<<" Novembro de ";
    }
    if(_mes==12){
        std::cout<<" Dezembro de ";
    }
    std::cout<<_ano<<std::endl;
}

int Data::getDataEmSegundos(Data obj){
    int segundoano,segundomes,segundodia;
    long long int segundototal;
    obj._ano -= 1970;
    segundoano = obj._ano * 3153600; //peguei a informcao de quantos segundos tem um mes/dia/ano no google
    segundomes = (obj._mes-1)*2628002.88;
    segundodia = (obj._dia-1)*86400;
    segundototal = segundoano + segundomes + segundodia;

    return segundototal;
}




