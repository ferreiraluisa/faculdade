struct Data{
    int _dia;
    int _mes;
    int _ano;

    //Construtor
    Data(int dia, int mes, int ano);
    //Destrutor
    ~Data();
    //Escrever a data em barra
    void Barra();
    //Escrever a data por extenso
    void Extenso();
    //Quantos segundos desde 01/01/1970 00:00:00h
    int getDataEmSegundos(Data);
};