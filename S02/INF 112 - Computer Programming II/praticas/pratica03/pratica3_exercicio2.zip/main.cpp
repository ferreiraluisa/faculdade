#include <iostream>
#include "data.h"

int main(){
    int dia,mes,ano;

    std::cout<<"Digite um dia,mes e ano por algarismos: ";
    std::cin>>dia>>mes>>ano;

    Data *objeto = new Data(dia,mes,ano);
    (*objeto).Barra();
    (*objeto).Extenso();
    std::cout<<(*objeto).getDataEmSegundos(*objeto)<<std::endl;

    delete objeto;

    return 0;
}
