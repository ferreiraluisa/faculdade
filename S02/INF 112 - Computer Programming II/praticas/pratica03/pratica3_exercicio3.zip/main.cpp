#include <iostream>
#include "aluno.h"

int main(){
    int materias;
    double nota;
    std::cout<<"Quantas materias o aluno cursa? ";
    std::cin>>materias;

    Aluno objeto(materias);
    objeto.inserir_dados();

    for(int i=0;i<materias;i++){
        std::cout<<"Cadastre a nota na materia "<<i+1<<": ";
        std::cin>>nota;
        objeto.adicionar_nota(nota);
    }

    std::cout<<"Media = "<<objeto.calcular_media()<<std::endl;

    objeto.imprime();

    return 0;
}