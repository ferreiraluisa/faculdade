#include <iostream>
#include "aluno.h"

Aluno::Aluno(int n){
    _notas = new double[n];
    _notas_inseridas = 0;
    _nome = new char[300];
    _matricula = new char[20];
}

Aluno::~Aluno(){
    delete[] _notas;
    delete[] _nome;
    delete[] _matricula;
}

void Aluno::inserir_dados(){
    std::cout<<"Digite o nome do aluno: ";
    std::cin>>_nome;
    std::cout<<"Digite a matricula do aluno: ";
    std::cin>>_matricula;
}

void Aluno::adicionar_nota(int nota){
    _notas[_notas_inseridas] =  nota;
    _notas_inseridas++;
    std::cout<<"Nota "<<_notas_inseridas<<" adicionada."<<std::endl;
}

double Aluno::calcular_media(){
    for(int i=0;i<_notas_inseridas;i++){
        _media_notas += _notas[i];
    }
    _media_notas = _media_notas / _notas_inseridas;
    return _media_notas;
}

void Aluno::imprime(){
    std::cout<<"NOME DO ALUNO: "<<_nome<<std::endl;
    std::cout<<"MATRICULA DO ALUNO: "<<_matricula<<std::endl;
    std::cout<<"----------------NOTAS DO ALUNO----------------"<<std::endl;
    for(int i=0;i<_notas_inseridas;i++){
        std::cout<<"MATERIA "<<i+1<<" : "<<_notas[i]<<std::endl;
    }
    std::cout<<"MEDIA DE NOTAS: "<<_media_notas<<std::endl;

}