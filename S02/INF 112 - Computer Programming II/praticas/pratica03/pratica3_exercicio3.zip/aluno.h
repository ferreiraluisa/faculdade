struct Aluno{
char *_nome;
char *_matricula;
double *_notas;
double _media_notas=0;
int _notas_inseridas;

Aluno(int n);

~Aluno();

void inserir_dados();

void adicionar_nota(int n);

double calcular_media();

void imprime();

};