class Soma{
    public:
        int soma_recursiva(int n,int m);

};