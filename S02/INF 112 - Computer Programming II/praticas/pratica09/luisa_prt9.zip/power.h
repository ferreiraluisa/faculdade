class Power{
    public:
        int potencia_recursiva(int k, int n);
};