class MDC{
    public:
        int mdc_recursiva(int x, int y);
};