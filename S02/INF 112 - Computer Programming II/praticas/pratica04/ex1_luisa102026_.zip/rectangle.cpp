#include <iostream>
#include "rectangle.h"

Rectangle::Rectangle(){ //Construtor
    lenght = 1;
    width = 1;
    validadelenght = true;
    validadewidth = true;
}

Rectangle::~Rectangle(){} //Destrutor

double Rectangle::getLenght(){
    return lenght;
}
void Rectangle::setLenght(double l){
    if(l<0 || l>20){
        std::cout<<"Medida invalida!"<<std::endl;
        validadelenght = false;
    }
        lenght = l;
    
}
double Rectangle::getWidth(){
    return width;
}
void Rectangle::setWidth(double w){
    if(w<0 || w>20){
        std::cout<<"Medida invalida!"<<std::endl;
        validadelenght = false;
    }
        width = w;

}

double Rectangle::perimeter(){
    if(validadelenght && validadewidth){
        return 2*lenght + 2*width;
    }
    else{
        return 0;
    }
}

double Rectangle::area(){
    if(validadelenght && validadewidth){
        return lenght*width;
    }
    else{
        return 0;
    }
}