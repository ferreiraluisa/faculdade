#include <iostream>
#include "rectangle.h"

int main(){
    Rectangle *objeto = new Rectangle;
    double comprimento, largura;

    std::cout<<"Digite a comprimento: ";
    std::cin>>comprimento;
    objeto->setLenght(comprimento);
    std::cout<<"Digite a largura: ";
    std::cin>>largura;
    objeto->setWidth(largura);

    std::cout<<"-----------------RETANGULO-------------------------"<<std::endl;
    std::cout<<"Comprimento: "<<objeto->getLenght()<<std::endl;
    std::cout<<"Largura: "<<objeto->getWidth()<<std::endl;
    if(objeto->perimeter()!=0 and objeto->area()!=0){
        std::cout<<"Perimetro do retangulo: "<<objeto->perimeter()<<std::endl;
        std::cout<<"Area do retangulo: "<<objeto->area()<<std::endl;
    }
    else{
        std::cout<<"Nao foi possivel calcular a area e/ou perimetro, medidas invalidas! Reinicie o programa ."<<std::endl;
    }

    delete objeto;

    return 0;

}