class Rectangle{
    private:
        double lenght;
        double width;
    public:
        bool validadelenght;
        bool validadewidth;
        Rectangle(); // construtor
        ~Rectangle(); //desconstrutor
        double getLenght();
        void setLenght(double l);
        double getWidth();
        void setWidth(double w);
        double perimeter();
        double area();
};