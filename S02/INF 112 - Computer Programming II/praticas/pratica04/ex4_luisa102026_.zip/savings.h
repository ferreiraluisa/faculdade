class SavingsAccount{
    private:
        double SavingsBalance;
    public:
        static double annualInterestRate;
        SavingsAccount(double valor);
        ~SavingsAccount();
        double calculateMonthlyInterest();
        static void modifyInterestRate(double n);

};