#include <iostream>
#include "savings.h"

SavingsAccount::SavingsAccount(double valor){
    SavingsBalance = valor;
}

SavingsAccount::~SavingsAccount(){}

double SavingsAccount::calculateMonthlyInterest(){
    double juros;
    juros = (SavingsBalance * (annualInterestRate/100))/12;
    SavingsBalance += juros;
    return SavingsBalance;
}

void SavingsAccount::modifyInterestRate(double n){
    annualInterestRate = n;
}
