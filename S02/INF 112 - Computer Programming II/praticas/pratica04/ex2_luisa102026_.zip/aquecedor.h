class Aquecedor{
    private:
        double temperatura;
    public:
        Aquecedor(); //construtor
        ~Aquecedor(); //destrutor
        double getTemperatura(); //metodo para retornar o valor da temperatura.
        void aquecer();
        void resfriar();
};