#include <iostream>
#include "aquecedor.h"

Aquecedor::Aquecedor(){
    temperatura = 20;
}

Aquecedor::~Aquecedor(){}

double Aquecedor::getTemperatura(){
    return temperatura;
}

void Aquecedor::aquecer(){ //n = numero de vezes que o usuario queira aquecer 5 graus ao ambiente
    temperatura += (5);
}

void Aquecedor::resfriar(){  //n = numero de vezes que o usuario queira resfriar 5 graus ao ambiente
    temperatura-=(5);
}