#include <iostream>
#include <iomanip>
#include "aquecedor.h"


int main(){
    Aquecedor *objeto = new Aquecedor; //T = 20
    
    std::cout<<"Temperatura inicial: "<<objeto->getTemperatura()<<std::endl;
    objeto->aquecer(); //T = 25
    std::cout<<"Temperatura atual: "<<objeto->getTemperatura()<<std::endl;
    objeto->resfriar(); //T = 20
    std::cout<<"Temperatura atual: "<<objeto->getTemperatura()<<std::endl;

    delete objeto;

    return 0;

}