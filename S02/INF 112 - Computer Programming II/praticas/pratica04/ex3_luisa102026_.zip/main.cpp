#include <iostream>
#include <iomanip>
#include "aquecedor.h"


int main(){
    Aquecedor *objeto = new Aquecedor; //Ti = 20, Fatori = 5
    Aquecedor *objeto1 = new Aquecedor(10); // Ti = 10, Fatori = 5
    Aquecedor *objeto2 =  new Aquecedor(35,10); //Ti =35, Fatori = 10
    
    std::cout<<"=====AQUECEDOR 1======"<<std::endl;
    std::cout<<"Temperatura inicial: "<<objeto->getTemperatura()<<std::endl;
    objeto->resfriar(); //T = 15
    if(objeto->limite){
        std::cout<<"Temperatura atual: "<<objeto->getTemperatura()<<std::endl;
    }
    objeto->aquecer(); //T = 20
    if(objeto->limite){
        std::cout<<"Temperatura atual: "<<objeto->getTemperatura()<<std::endl;
    }
    std::cout<<std::endl;

    std::cout<<"=====AQUECEDOR 2======"<<std::endl;
    std::cout<<"Temperatura inicial: "<<objeto1->getTemperatura()<<std::endl;
    objeto1->resfriar(); //T = 5 (nao pode, tem que dar aviso)
    if(objeto1->limite){
        std::cout<<"Temperatura atual: "<<objeto1->getTemperatura()<<std::endl;
    }
    objeto1->aquecer(); //T = 15
    if(objeto1->limite){
        std::cout<<"Temperatura atual: "<<objeto1->getTemperatura()<<std::endl;
    }
    std::cout<<std::endl;

    std::cout<<"=====AQUECEDOR 3======"<<std::endl;
    std::cout<<"Temperatura inicial: "<<objeto2->getTemperatura()<<std::endl;
    objeto2->aquecer(); //T = 45(nao pode, tem que dar aviso)
    if(objeto2->limite){
        std::cout<<"Temperatura atual: "<<objeto2->getTemperatura()<<std::endl;
    }
    objeto2->resfriar(); //T = 25
    if(objeto2->limite){
        std::cout<<"Temperatura atual: "<<objeto2->getTemperatura()<<std::endl;
    }
    std::cout<<std::endl;

    delete objeto;
    delete objeto1;
    delete objeto2;

    return 0;

}