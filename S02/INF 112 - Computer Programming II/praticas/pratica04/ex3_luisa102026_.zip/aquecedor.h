class Aquecedor{
    private:
        double Temperatura;
        double Tempmaxima;
        double Tempminima;
        double Fatori; // fator incremento de temperatura
    public: 
        bool limite;
        Aquecedor(); //construtor
        Aquecedor(double ti);
        Aquecedor(double ti, double n);
        ~Aquecedor(); //destrutor
        void setFatori(double n);
        double getTemperatura(); //metodo para retornar o valor da temperatura.
        double getTempmaxima();
        double getTempminima();
        void aquecer();
        void resfriar();
};