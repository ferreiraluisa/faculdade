#include <iostream>
#include "aquecedor.h"

Aquecedor::Aquecedor(){
    Fatori = 5;
    Temperatura = 20;
    Tempmaxima = 40;
    Tempminima = 10;
}

Aquecedor::Aquecedor(double ti){
    Fatori = 5;
    Temperatura = ti;
    Tempmaxima = 40;
    Tempminima = 10;
}

Aquecedor::Aquecedor(double ti, double n){
    Fatori = n;
    Temperatura = ti;
    Tempmaxima = 40;
    Tempminima = 10;
}

Aquecedor::~Aquecedor(){}

void Aquecedor::setFatori(double n){
    this->Fatori = n;
}

double Aquecedor::getTemperatura(){
    return Temperatura;
}

double Aquecedor::getTempmaxima(){
    return Tempmaxima;
}

double Aquecedor::getTempminima(){
    return Tempminima;
}

void Aquecedor::aquecer(){ //n = numero de vezes que o usuario queira aquecer 5 graus ao ambiente
    std::cout<<"Aquecendo..."<<std::endl;
    double aux = Temperatura; //variavel auxiliar para gravar o valor da temperatura caso ela ultrapasse o limite minimo
    limite = true; // se esta dentro do limite
    this->Temperatura += Fatori;
    if(Temperatura>Tempmaxima){
        std::cout<<"Atencao!O limite maximo de temperatura foi alcancado."<<std::endl;
        limite = false; //esta fora, por isso o false
        this->Temperatura = aux; //iguala a temperatura inicial ja que ela nao pode mudar
    }
}

void Aquecedor::resfriar(){  //n = numero de vezes que o usuario queira resfriar 5 graus ao ambiente
    std::cout<<"Resfriando..."<<std::endl;
    double aux = Temperatura; //variavel auxiliar para gravar o valor da temperatura caso ela ultrapasse o limite minimo
    limite = true;
    this->Temperatura -= Fatori;
    if(Temperatura<Tempminima){
        std::cout<<"Atencao!O limite minimo de temperatura foi alcancado."<<std::endl;
        limite = false; 
        this->Temperatura = aux;
    }
}