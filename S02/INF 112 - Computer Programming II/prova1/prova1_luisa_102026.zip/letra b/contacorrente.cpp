#include "contacorrente.h"

ContaCorrente::ContaCorrente(std::string nome, std::string cpf, double saldo):
    Conta(nome,cpf,saldo) {}

ContaCorrente::~ContaCorrente(){}
