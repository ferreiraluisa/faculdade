# OpenGL 2D scene start

## Quick Start

```console
$ sudo apt-get install libglfw3
$ sudo apt-get install libglfw3-dev
$ cd project_folder
$ mkdir build
$ cmake ..
$ make
$ ./my_opengl_project
```
